#include "globaldefine.h"
#include "global.h"
#include "constantes.h"

/**
 * Initialisation de Timer0  pour generer 1 signal � 1us
 *
 */
void T0_Init(void)
{
	TIM_TIMERCFG_Type		Timer_Config_Structure; 
  TIM_MATCHCFG_Type		Timer_MatchConfig_Structure;
	
	
	Timer_Config_Structure.PrescaleOption = TIM_PRESCALE_USVAL;					
	Timer_Config_Structure.PrescaleValue	= TIMER0_TIME_STEP;							

	TIM_Init(LPC_TIM0, TIM_TIMER_MODE,&Timer_Config_Structure);
	


	Timer_MatchConfig_Structure.MatchChannel = 0;													
	Timer_MatchConfig_Structure.IntOnMatch   = TRUE;											
	Timer_MatchConfig_Structure.ResetOnMatch = TRUE;										
	Timer_MatchConfig_Structure.StopOnMatch  = FALSE;										
	Timer_MatchConfig_Structure.ExtMatchOutputType = TIM_EXTMATCH_NOTHING;	
	
	Timer_MatchConfig_Structure.MatchValue = TIMER0_MATCH_VALUE_1us;		
	TIM_ConfigMatch(LPC_TIM0,&Timer_MatchConfig_Structure);								
	
	
	TIM_Cmd(LPC_TIM0,ENABLE);																							

	NVIC_EnableIRQ(TIMER0_IRQn);
}

//===========================================================//
// Routine d'interruption de Timer0
//===========================================================//
void TIMER0_IRQHandler(void){
	//mise � jour de globalTime0
	globalTime0 = globalTime0 + 1;
	// R�ajuste IR
	LPC_TIM0->IR=(1<<0); 
	TIM_ClearIntPending(LPC_TIM0, TIM_MR0_INT);
}
