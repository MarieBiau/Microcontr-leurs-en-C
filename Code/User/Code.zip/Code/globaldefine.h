// fichier contenant l'inclusion des typedef qui servent � toute l'application
// � inclure dans tous les fichiers

#include "lpc17xx.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_libcfg.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_timer.h"



