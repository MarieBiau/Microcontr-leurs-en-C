//fichier contenant l'inclusion des #define qui servent � toute l'application
//� inclure dans tous les fichiers

#define TIMER0_TIME_STEP			1			// 1 us de Step Timer
#define TIMER0_MATCH_VALUE_1us  1 // valeur pour avoir 1 us 
//en theorie 1, mais sur simulation, on est alors plus proche de 2us 
