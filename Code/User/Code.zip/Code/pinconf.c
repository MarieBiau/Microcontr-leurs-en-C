#include "globaldefine.h"
#include "global.h"


void pin_Configuration(void)
{
 
	PINSEL_CFG_Type maconfig;
	
	

	//GPIO0
	GPIO_SetDir(0,0,0);
	

	
	// Config MAT0
	maconfig.Portnum = PINSEL_PORT_1;
	maconfig.Pinnum =PINSEL_PIN_28;
	maconfig.Funcnum = PINSEL_FUNC_3;
	maconfig.Pinmode =PINSEL_PINMODE_PULLDOWN;
	maconfig.OpenDrain = PINSEL_PINMODE_NORMAL;
  PINSEL_ConfigPin(&maconfig);
	
	//GPIO1
	GPIO_SetDir(1,512,1); //P1.9
	
	//Config P1.9
	maconfig.Portnum = PINSEL_PORT_1;
	maconfig.Pinnum =PINSEL_PIN_9;
	maconfig.Funcnum = PINSEL_FUNC_0;
	maconfig.Pinmode =PINSEL_PINMODE_PULLDOWN;
	maconfig.OpenDrain = PINSEL_PINMODE_NORMAL;
	PINSEL_ConfigPin(&maconfig);
	
}
