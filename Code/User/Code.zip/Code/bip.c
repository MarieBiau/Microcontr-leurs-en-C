#include "globaldefine.h"
#include "global.h"

/*
 * Gen�ration d'un signal carre 
 *(g�n�ration d'une p�riode, � mettre dans une boucle while)
*/
void bip(){
	
	unsigned int duree;
	unsigned int currTime;
	unsigned int prevTime;
	
	currTime = globalTime0;
	duree = 0;
	
	while(duree <200000){
		GPIO_SetValue(1,512);
		prevTime = currTime;
		currTime = globalTime0;
		duree = duree + (currTime-prevTime);//rajouter modulo 2^32 pour g�rer cas raz de globalTime
	}
	
	duree = 0;
	while(duree <200000){
		GPIO_ClearValue(1,512);
		prevTime = currTime;
		currTime = globalTime0;
		duree = duree + (currTime-prevTime);//rajouter modulo 2^32 pour g�rer cas raz de globalTime
	}
	
}
