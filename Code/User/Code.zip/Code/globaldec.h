// fichier contenant la d�claration des variables globales de l'application
// � inclure seulement dans le main

unsigned int globalTime0;
