// fichier contenant l'importation des variables globales de l'application
// � inclure dans les autres fichiers que le main

#include "globaldefine.h"

extern unsigned int globalTime0;
